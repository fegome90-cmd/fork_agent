# fork_terminal

Implementaciones y notas sobre la skill `fork_terminal`.

Esta skill ofrece mecanismos para preparar, simular y (con confirmación) ejecutar comandos en la terminal desde un contexto controlado y auditable.

Recomendación: usar siempre `--dry-run` o entornos aislados al probar.
