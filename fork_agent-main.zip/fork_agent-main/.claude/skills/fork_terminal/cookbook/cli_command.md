# Purpose

Ejecuta un comando CLI crudo.

## Instructions

- Antes de ejecutar el comando, corre "<command> --help" para entender el comando y sus opciones.
- Lee la solicitud del usuario.
- Ejecuta el comando en una nueva terminal de window.