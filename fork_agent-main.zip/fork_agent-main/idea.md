.claude
    skills/
        skills.md
        fork_terminal/
        tools/
            fork_terminal.py
        prompts/
            fork_summary_user_prompts.md
        cookbook/
            cli_command.md
            gemini_cli.md
            codex_cli.md
            claude_code.md

.gitignore - python defaults
.env.sample - api_keys
README.md - 